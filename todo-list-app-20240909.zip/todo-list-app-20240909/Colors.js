// Colors.js
export default colors={
    black: "#2D3436",
    gray:"#A4A4A4",
    lightgray: "#CACACA",
    blue: "#24A6D9",
    lightBlue: "#A7CBD9",
    white:"#FFFFFF",
    
  };
  